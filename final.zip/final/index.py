import requests , json , csv
import pandas as pd
import pymysql
import matplotlib as mpl
import matplotlib.pyplot as plt 
from matplotlib.font_manager import fontManager
# matplotlib字型設定
plt.rcParams['font.sans-serif'] = ['Microsoft JhengHei'] 
plt.rcParams['axes.unicode_minus'] = False

#抓取高鐵資料
url = 'https://www.rb.gov.tw/public/files/artsinfo/1654651913-m0.csv'
df = pd.read_csv(url)
data = df[['年','月','旅客人數','列車次數','準點率']] #用pd的dataframe整理資料
data.to_csv('HSR.csv' , index=False , header=False , encoding='utf8') #將資料儲存成csv檔

# mysql
conn = pymysql.connect(host='192.168.186.131' , port=3306 , user='root' ,passwd='c110156217' ,db='HSR' , charset='utf8') #建立連線
cursor = conn.cursor() #建立游標(下命令)的通道
cursor.execute("TRUNCATE `HSR`;") #新增資料前先清空資料表
for i in range(len(data['月'])): #將每月資料整理好後放入SQL
    tmp_year = data.loc[i , ['年']].values[0]
    tmp_month = data.loc[i , ['月']].values[0]
    tmp_peple = data.loc[i , ['旅客人數']].values[0]
    tmp_train = data.loc[i , ['列車次數']].values[0]
    tmp_pr = data.loc[i , ['準點率']].values[0]
    cursor.execute("INSERT INTO `HSR` (`年`, `月`, `旅客人數`, `列車次數`, `準點率`) VALUES ('" + str(tmp_year) +"', '" + str(tmp_month) +"', '" + str(tmp_peple) + "', '" + str(tmp_train) + "', '" + str(tmp_pr) + "')")
conn.commit()
cursor.close()
conn.close()
print(data.groupby('年').sum())

# csv -> json 因為準點率有%符號，所以先將準點率獨自提出到一個檔案，再進行資料分析。
f = open('HSR.csv','r',encoding='utf-8')
data_pr = f.readlines()
result = [] 
for  i in data_pr:
    tmp_dict = {}
    tmp = i.split(',') ;
    tmp_pr = float(tmp[4].split('%')[0])/100
    tmp_dict['年'] = int(tmp[0])
    tmp_dict['準點率'] = tmp_pr
    result.append(tmp_dict)
f.close()
r = open('result.json','w',encoding='utf-8')
result_json = json.dumps(result,indent=4,ensure_ascii=False)
r.write(result_json)
r.close()

re = open('result.json','r',encoding='utf-8')
data_re = json.load(re)
data_re = pd.DataFrame(data_re)
print(data_re)

#彙整
dataPeople = data.groupby('年').sum()['旅客人數']
dataTrain = data.groupby('年').sum()['列車次數']
dataPr = data_re.groupby('年').mean()['準點率']


#畫圖表
dataPeople.plot.bar(title="高鐵各年度旅客人數",figsize=[15,10])
plt.ylabel('千萬/人')
plt.savefig('./pic/HSR/各年度旅客人數長條圖.jpg',dpi=1000)
plt.show()

dataTrain.plot.bar(title="高鐵各年度列車次數",figsize=[15,10])
plt.ylabel('列車次數')
plt.savefig('./pic/HSR/各年度列車次數長條圖.jpg',dpi=1000)
plt.show()

dataPr.plot(title="高鐵各年度準點率",figsize=[15,10] , c="g")
plt.savefig('./pic/HSR/各年度準點率折線圖.jpg',dpi=1000)
plt.show()

