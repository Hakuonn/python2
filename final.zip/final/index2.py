import requests ,json , csv
import pandas as pd
import pymysql
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.font_manager import fontManager, json_load
plt.rcParams['font.sans-serif'] = ['Microsoft JhengHei']
plt.rcParams['axes.unicode_minus'] = False

url = 'https://www.rb.gov.tw/public/files/artsinfo/1654652040-m0.csv'
df = pd.read_csv(url)
data = df[['發生年度','發生月份', '事故事件種類','原因別']].dropna()
data.to_csv('HSRaccident.csv', index=False, header=False, encoding='utf8')
print(data['發生月份'])

# 抓資料到SQL
conn = pymysql.connect(host='192.168.186.131' , port=3306 , user='root' ,passwd='c110156217' ,db='HSR' , charset='utf8') #建立連線
cursor = conn.cursor() #建立游標(下命令)的通道
cursor.execute("TRUNCATE `HSRAccident`;") #新增資料前先清空資料表
year = []
for i in range(len(data['發生年度'])):
    tmp_year = int(data.loc[i , ['發生年度']].values[0])
    if  tmp_year not in year:
        year.append(tmp_year)
    tmp_month = data.loc[i,['發生月份']].values[0]
    tmp_accident = data.loc[i , ['事故事件種類']].values[0]
    tmp_cause = data.loc[i , ['原因別']].values[0]
    cursor.execute("INSERT INTO `HSRAccident` (`發生年度`, `發生月份`, `事故事件種類`, `原因別`) VALUES ('" + str(tmp_year) +"', '" + str(tmp_month) +"', '" + str(tmp_accident) +"', '" + str(tmp_cause) +"')")
conn.commit()
cursor.close()
conn.close()

# csv -> json
f = open('HSRaccident.csv', 'r', encoding='utf-8')
dataAC = f.readlines()
result = []
for i in dataAC:
    tmp_dict = {}
    tmp = i.split('/n')[0]
    tmp_year = tmp.split(',')[0].split('.')[0]
    tmp_dict['發生年度'] = int(tmp_year)
    tmp_dict['事故事件種類'] = tmp.split(',')[2].split('\n')[0]
    result.append(tmp_dict)
f.close()

f = open('accident.json', 'w', encoding='utf-8')
dataAC_json = json.dumps(result, indent=4, ensure_ascii=False)
f.write(dataAC_json)
f.close()

f = open('accident.json', 'r', encoding='utf-8')
accident = json.load(f)
accident = pd.DataFrame(accident)
f.close()

print(accident)

for i in year:
    tmp_accident = accident[accident['發生年度'] == i]
    dataAccident = accident.groupby('事故事件種類').count()['發生年度']
    dataaccident = tmp_accident.groupby('事故事件種類').count()['發生年度']

    dataaccident.plot.pie(autopct='%1.1f%%')
    plt.title(str(i)+'年高鐵事故')
    plt.ylabel('')
    plt.savefig('./pic/accident/民國{}年故圓餅圖.jpg'.format(i),dpi=1000)
    plt.show()
